import express from "express";
import sqlite3 from "sqlite3";
import { open } from "sqlite";
import cron from "node-cron";
import twilio from "twilio";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
app.use(express.json());

const client = twilio(process.env.TWILIO_SID, process.env.TWILIO_AUTH);
let db;

(async () => {
  db = await open({ filename: "./clinic.db", driver: sqlite3.Database });
  await db.exec('CREATE TABLE IF NOT EXISTS appointments (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT, date TEXT, notifyMethod TEXT)');
})();

app.get("/api/appointments", async (req, res) => {
  const rows = await db.all("SELECT * FROM appointments ORDER BY date ASC");
  res.json(rows);
});

app.post("/api/appointments", async (req, res) => {
  const { name, phone, date, notifyMethod } = req.body;
  await db.run("INSERT INTO appointments (name, phone, date, notifyMethod) VALUES (?,?,?,?)", [name, phone, date, notifyMethod]);
  res.sendStatus(200);
});

app.delete("/api/appointments/:id", async (req, res) => {
  await db.run("DELETE FROM appointments WHERE id=?", [req.params.id]);
  res.sendStatus(200);
});

app.post("/api/appointments/:id/send", async (req, res) => {
  const row = await db.get("SELECT * FROM appointments WHERE id=?", [req.params.id]);
  await sendReminder(row);
  res.sendStatus(200);
});

async function sendReminder(row) {
  const msg = `Reminder: Dear ${row.name}, your appointment is on ${new Date(row.date).toLocaleString()}.`;
  if (row.notifyMethod === "sms" || row.notifyMethod === "both") {
    await client.messages.create({ from: process.env.TWILIO_SMS_FROM, to: row.phone, body: msg });
  }
  if (row.notifyMethod === "whatsapp" || row.notifyMethod === "both") {
    await client.messages.create({ from: process.env.TWILIO_WA_FROM, to: `whatsapp:${row.phone}`, body: msg });
  }
}

cron.schedule("0 8 * * *", async () => {
  const target = new Date();
  target.setDate(target.getDate() + 2);
  const day = target.toISOString().split("T")[0];
  const rows = await db.all("SELECT * FROM appointments WHERE date LIKE ?", [`${day}%`]);
  for (const row of rows) await sendReminder(row);
  console.log("Daily reminder job executed");
});

app.use(express.static(path.join(__dirname, "../client/dist")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "../client/dist/index.html")));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

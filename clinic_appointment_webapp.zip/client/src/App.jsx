import React, { useEffect, useState } from "react";

export default function App() {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [date, setDate] = useState("");
  const [method, setMethod] = useState("sms");
  const [appointments, setAppointments] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function fetchAppointments() {
    setLoading(true);
    try {
      const res = await fetch("/api/appointments");
      const data = await res.json();
      setAppointments(data);
    } catch {
      setError("Failed to load appointments");
    }
    setLoading(false);
  }

  useEffect(() => { fetchAppointments(); }, []);

  async function addAppointment(e) {
    e.preventDefault();
    try {
      const res = await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, phone, date, notifyMethod: method }),
      });
      if (!res.ok) throw new Error();
      setName(""); setPhone(""); setDate("");
      fetchAppointments();
    } catch {
      setError("Failed to add appointment");
    }
  }

  async function sendNow(id) {
    await fetch(`/api/appointments/${id}/send`, { method: "POST" });
    alert("Reminder sent!");
  }

  async function remove(id) {
    await fetch(`/api/appointments/${id}`, { method: "DELETE" });
    fetchAppointments();
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Clinic Appointment Manager</h1>

      <form onSubmit={addAppointment} className="grid grid-cols-1 md:grid-cols-4 gap-3 bg-white p-4 rounded-xl shadow">
        <input placeholder="Name" value={name} onChange={e=>setName(e.target.value)} className="p-2 border rounded" />
        <input placeholder="Phone" value={phone} onChange={e=>setPhone(e.target.value)} className="p-2 border rounded" />
        <input type="datetime-local" value={date} onChange={e=>setDate(e.target.value)} className="p-2 border rounded" />
        <div>
          <select value={method} onChange={e=>setMethod(e.target.value)} className="p-2 border rounded w-full">
            <option value="sms">SMS</option>
            <option value="whatsapp">WhatsApp</option>
            <option value="both">Both</option>
          </select>
          <button type="submit" className="mt-2 bg-indigo-600 text-white rounded w-full py-2">Add</button>
        </div>
      </form>

      {error && <p className="text-red-600 mt-2">{error}</p>}

      <div className="mt-6 bg-white p-4 rounded-xl shadow">
        <h2 className="font-semibold mb-2">Appointments</h2>
        {loading ? <p>Loading…</p> : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-gray-500">
                <th>Name</th><th>Phone</th><th>Date</th><th>Method</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {appointments.map(a => (
                <tr key={a.id} className="border-t">
                  <td>{a.name}</td><td>{a.phone}</td><td>{new Date(a.date).toLocaleString()}</td><td>{a.notifyMethod}</td>
                  <td>
                    <button onClick={()=>sendNow(a.id)} className="px-2 border rounded mr-2">Send</button>
                    <button onClick={()=>remove(a.id)} className="px-2 border rounded text-red-600">Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
